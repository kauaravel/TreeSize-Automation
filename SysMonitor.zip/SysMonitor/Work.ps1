$HiddenDir = "C:\ProgramData\SysMonitor"
$ReportFile = "$HiddenDir\Relatorio_Disco.txt"
$LimiteBytes = 5GB

if (Test-Path $HiddenDir) { (Get-Item $HiddenDir -Force).Attributes = 'Normal' }

Function Get-TamanhoSeguro($Caminho, $Nivel) {
    $TamanhoTotal = 0
    $SubItens = @()
    
    # Otimiza��o: Uso do Measure-Object direto na mem�ria (muito mais r�pido que o foreach)
    $SomaArq = Get-ChildItem $Caminho -File -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum
    if ($SomaArq.Sum) { $TamanhoTotal += $SomaArq.Sum }

    if ($Nivel -lt 3) {
        $Diretorios = Get-ChildItem $Caminho -Directory -Force -ErrorAction SilentlyContinue -Attributes !ReparsePoint
        foreach ($Dir in $Diretorios) {
            $Resultado = Get-TamanhoSeguro -Caminho $Dir.FullName -Nivel ($Nivel + 1)
            $TamanhoTotal += $Resultado.Total
            
            if ($Resultado.Total -ge $LimiteBytes) {
                $Prefixo = if ($Nivel -eq 1) { "    |-- " } else { "        |-- " }
                $SubItens += [PSCustomObject]@{
                    Pasta = "$Prefixo$($Dir.Name)"
                    Bytes = $Resultado.Total
                    'Tamanho' = "$([math]::Round($Resultado.Total / 1GB, 2)) GB".PadRight(12)
                    'Modificado' = $Dir.LastWriteTime.ToString("dd/MM/yyyy HH:mm")
                    Filhos = $Resultado.Filhos
                }
            }
        }
    } else {
        $SomaFundo = Get-ChildItem $Caminho -Recurse -File -Force -ErrorAction SilentlyContinue -Attributes !ReparsePoint | Measure-Object -Property Length -Sum
        if ($SomaFundo.Sum) { $TamanhoTotal += $SomaFundo.Sum }
    }
    
    return [PSCustomObject]@{ Total = $TamanhoTotal; Filhos = ($SubItens | Sort-Object Bytes -Descending) }
}

$PastasRaiz = Get-ChildItem "C:\" -Directory -Force -ErrorAction SilentlyContinue -Attributes !ReparsePoint
$DadosAnalisados = @()

foreach ($P1 in $PastasRaiz) {
    $Info = Get-TamanhoSeguro -Caminho $P1.FullName -Nivel 1
    if ($Info.Total -ge $LimiteBytes) {
        $DadosAnalisados += [PSCustomObject]@{
            Nome = $P1.FullName
            Bytes = $Info.Total
            'Tamanho' = "$([math]::Round($Info.Total / 1GB, 2)) GB".PadRight(12)
            'Modificado' = $P1.LastWriteTime.ToString("dd/MM/yyyy HH:mm")
            SubPastas = $Info.Filhos
        }
    }
}

$RelatorioFinal = @()
foreach ($Item1 in ($DadosAnalisados | Sort-Object Bytes -Descending)) {
    $RelatorioFinal += [PSCustomObject]@{ Pasta = $Item1.Nome; 'Tamanho' = $Item1.'Tamanho'; 'Ultima Modificacao' = $Item1.'Modificado' }
    foreach ($Item2 in $Item1.SubPastas) {
        $RelatorioFinal += [PSCustomObject]@{ Pasta = $Item2.Pasta; 'Tamanho' = $Item2.'Tamanho'; 'Ultima Modificacao' = $Item2.'Modificado' }
        foreach ($Item3 in $Item2.Filhos) {
            $RelatorioFinal += [PSCustomObject]@{ Pasta = $Item3.Pasta; 'Tamanho' = $Item3.'Tamanho'; 'Ultima Modificacao' = $Item3.'Modificado' }
        }
    }
}

$RelatorioFormatado = $RelatorioFinal | Format-Table Pasta, Tamanho, 'Ultima Modificacao' -AutoSize | Out-String
$RelatorioFormatado | Out-File -FilePath $ReportFile -Encoding utf8